# Car-Brands-Classification
A very simple Image Classification using ResNet-50 and Convolutional Neural Networks(CNN) and ResNet50.
